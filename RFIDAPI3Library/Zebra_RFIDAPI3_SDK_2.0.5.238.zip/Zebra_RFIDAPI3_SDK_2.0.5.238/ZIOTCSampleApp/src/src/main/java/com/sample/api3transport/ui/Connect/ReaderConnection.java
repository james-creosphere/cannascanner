package com.sample.api3transport.ui.Connect;

public interface ReaderConnection {
    void onConnected();
}
